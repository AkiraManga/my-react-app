import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "../styles/ChartsPage.css";

const FIRST_YEAR = 1970;
const THIS_YEAR = new Date().getFullYear();

export default function ChartsPage() {
  const navigate = useNavigate();
  const location = useLocation();

  const [config, setConfig] = useState(null);
  const [year, setYear] = useState(THIS_YEAR);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const scrollRef = useRef(null);
  const yearRefs = useRef({}); // ref ai bottoni anni

  // carica config una sola volta
  const getConfig = useMemo(() => {
    let cache = null;
    return async () => {
      if (cache) return cache;
      const r = await fetch("/config.json");
      cache = await r.json();
      return cache;
    };
  }, []);

  useEffect(() => {
    (async () => {
      const c = await getConfig();
      setConfig(c);
    })();
  }, [getConfig]);

  // 🟡 Legge l'anno da URL o localStorage ogni volta che cambia la query
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    let y = parseInt(params.get("year") || "", 10);

    if (!Number.isFinite(y)) {
      const ls = parseInt(localStorage.getItem("chartsYear") || "", 10);
      y = Number.isFinite(ls) ? ls : THIS_YEAR;
    }

    y = Math.max(FIRST_YEAR, Math.min(THIS_YEAR, y));
    setYear(y);
  }, [location.search]);

  // 🔵 Cambia anno: aggiorna stato + URL + localStorage
  const selectYear = (y) => {
    setYear(y);
    localStorage.setItem("chartsYear", String(y));
    const params = new URLSearchParams(location.search);
    params.set("year", String(y));
    navigate({ pathname: "/charts", search: `?${params.toString()}` }, { replace: true });
  };

  // 📡 Fetch classifica quando abbiamo config e year
  useEffect(() => {
    if (!config || !year) return;
    (async () => {
      try {
        setLoading(true);
        setErr("");
        const res = await fetch(`${config.apiBaseUrl}charts/${year}`);
        if (!res.ok) throw new Error(`(${res.status}) ${await res.text()}`);
        const data = await res.json();
        setItems(data.items || []);
      } catch (e) {
        setItems([]);
        setErr(e.message || "Errore");
      } finally {
        setLoading(false);
      }
    })();
  }, [config, year]);

  // Lista anni dal più recente al 1970
  const years = [];
  for (let y = THIS_YEAR; y >= FIRST_YEAR; y--) years.push(y);

  // ▶︎ frecce scroll
  const scroll = (dir) => {
    if (!scrollRef.current) return;
    const width = scrollRef.current.clientWidth;
    scrollRef.current.scrollBy({ left: dir === "left" ? -width : width, behavior: "smooth" });
  };

  // 💾 salva e ripristina scroll della barra anni (opzionale)
  useEffect(() => {
    const saved = parseInt(localStorage.getItem("chartsYearScroll") || "0", 10);
    if (scrollRef.current && saved > 0) {
      scrollRef.current.scrollLeft = saved;
    }
  }, []);
  const onYearScroll = () => {
    if (scrollRef.current) {
      localStorage.setItem("chartsYearScroll", String(scrollRef.current.scrollLeft));
    }
  };

  // 🎯 centra il bottone dell'anno attivo nella barra
  useEffect(() => {
    const el = yearRefs.current[year];
    if (el && scrollRef.current) {
      el.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
    }
  }, [year]);

  return (
    <div className="charts-page">
      <div className="charts-container">
        <div className="charts-header">
          <h1>Classifica album</h1>
        </div>

        {/* Barra anni */}
        <div className="year-bar-wrapper">
          <button className="year-arrow left" onClick={() => scroll("left")}>‹</button>

          <div className="year-bar" ref={scrollRef} onScroll={onYearScroll}>
            {years.map((y) => (
              <button
                key={y}
                ref={(el) => (yearRefs.current[y] = el)}
                data-year={y}
                className={`year-btn ${year === y ? "active" : ""}`}
                onClick={() => selectYear(y)}
              >
                {y}
              </button>
            ))}
          </div>

          <button className="year-arrow right" onClick={() => scroll("right")}>›</button>
        </div>

        {loading && <p>Caricamento…</p>}
        {err && <p className="text-red-400">{err}</p>}
        {!loading && !err && items.length === 0 && (
          <p className="text-gray-400">Nessun dato per questo anno.</p>
        )}

        {/* Lista classifica */}
        <ul className="chart-list">
          {items.map((it, idx) => (
            <li key={idx} className="chart-item">
              <div className="chart-rank">
                {it.rank && it.rank > 0 ? it.rank : idx + 1}
              </div>

              {it.cover && (
                <img src={it.cover} alt={it.title} className="chart-cover" />
              )}

              <div className="chart-info">
                <p className="title">{it.title}</p>
                <p className="artist">{it.artist}</p>
                <p className="year">{it.release_date || it.year || ""}</p>
              </div>

              <div className="chart-stats">
                <p className="score">⭐ {Number(it.score ?? 0).toFixed(2)}</p>
                <p className="votes">/ {it.ratings_count ?? 0}</p>
                <p className="reviews">{it.reviews_count ?? 0} recensioni</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
